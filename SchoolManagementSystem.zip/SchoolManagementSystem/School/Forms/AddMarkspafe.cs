﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School
{
    public partial class AddMarkspafe : Form
    {
        public AddMarkspafe()
        {
            InitializeComponent();
        }

        private void AddMarkspafe_Load(object sender, EventArgs e)
        {
            
        }
    }
}
